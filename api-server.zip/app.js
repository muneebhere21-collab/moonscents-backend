// Production entry point for cPanel Node.js App
// This file bootstraps the TypeScript server using tsx
import { register } from "tsx/esm/api";
register();
await import("./server/index.ts");
