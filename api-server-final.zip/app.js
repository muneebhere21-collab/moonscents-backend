// CommonJS entry point for cPanel
require("./dist-server/config/load-env.js");
const { createApp } = require("./dist-server/app.js");
const { getEnv } = require("./dist-server/config/env.js");

const env = getEnv();
const app = createApp();

app.listen(env.PORT, "0.0.0.0", () => {
  console.log(`Moonscents API running on port ${env.PORT}`);
});
