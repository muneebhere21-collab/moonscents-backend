// Production entry point for cPanel Node.js App
// Uses pre-compiled JavaScript - no TypeScript runtime needed
import "./dist-server/config/load-env.js";
import { createApp } from "./dist-server/app.js";
import { getEnv } from "./dist-server/config/env.js";

async function bootstrap() {
  const env = getEnv();
  const app = createApp();
  app.listen(env.PORT, "0.0.0.0", () => {
    console.log(`Moonscents API running on http://0.0.0.0:${env.PORT}`);
  });
}

bootstrap().catch((error) => {
  console.error("Failed to start API", error);
  process.exit(1);
});
